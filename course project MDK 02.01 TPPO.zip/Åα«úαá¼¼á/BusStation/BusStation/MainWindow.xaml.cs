﻿using BusStation.Authorization;
using BusStation.Mains;
using System.Data;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BusStation
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public string UserRole { get; private set; }

        public MainWindow()
        {
            InitializeComponent();

            Height += 30;
            Width += 30;

            AuthorizationWindow authWindow = new AuthorizationWindow();
            bool? authResult = authWindow.ShowDialog();  

            if (authResult != true) 
            {
                MessageBox.Show("Вы не авторизованы. Завершение работы.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                Application.Current.Shutdown();  
                return;  
            }

            UserRole = authWindow.UserRole;
            SetAccessRights();
        }
        /// <summary>
        /// Для гостя
        /// </summary>
        /// <param name="userRole"></param>
        public MainWindow(string userRole)
        {
            InitializeComponent();
            UserRole = userRole;
            SetAccessRights();
        }
        /// <summary>
        /// Выход
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// Переход на окно с таблицей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFlight_Click(object sender, RoutedEventArgs e)
        {
            FlightWindow flightWindow = new FlightWindow(UserRole);
            flightWindow.Show();
        }
        /// <summary>
        /// Переход на окно с таблицей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSchedule_Click(object sender, RoutedEventArgs e)
        {
            ScheduleWindow scheduleWindow = new ScheduleWindow(UserRole);
            scheduleWindow.Show();
        }
        /// <summary>
        /// Переход на окно с таблицей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnBus_Click(object sender, RoutedEventArgs e)
        {
            BusWindow busWindow = new BusWindow(UserRole);
            busWindow.Show();
        }
        /// <summary>
        /// Переход на окно с таблицей
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEmployee_Click(object sender, RoutedEventArgs e)
        {
            EmployeeWindow employeeWindow = new EmployeeWindow(UserRole);
            employeeWindow.Show();
        }
        /// <summary>
        /// Параметры для гостя
        /// </summary>
        private void SetAccessRights()
        {
            if (UserRole == "Guest")
            {
                btnFlight.IsEnabled = true;
                btnSchedule.IsEnabled = true;
                btnBus.IsEnabled = true;
                btnEmployee.IsEnabled = true;
            }
        }
    }
}