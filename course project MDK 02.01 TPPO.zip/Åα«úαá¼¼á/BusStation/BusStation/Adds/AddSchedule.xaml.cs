﻿using BusStation.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;

namespace BusStation.Adds
{
    /// <summary>
    /// Логика взаимодействия для AddSchedule.xaml
    /// </summary>
    public partial class AddSchedule : Window
    {
        BusStationContext _db = new BusStationContext();

        Schedule _schedule;

        public AddSchedule()
        {
            InitializeComponent();

            Height += 30;
            Width += 30;
        }
        /// <summary>
        /// Загрузка данных из кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Title = "Добавить запись.";
            btnAddSchedule.Content = "Добавить.";
            _schedule = new Schedule();
            cbFlightId.ItemsSource = _db.Flights.ToList();
            cbFlightId.DisplayMemberPath = "FlightId";
            DataContext = _schedule;
        }
        /// <summary>
        /// Назад
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow("Guest");
            this.Close();
        }
        /// <summary>
        /// Добавление кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddSchedule_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (dpArrivalTime.Text.Length == 0 || dpDepartureTime.Text.Length == 0)
            {
                MessageBox.Show("Заполните все поля!", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (cbFlightId.SelectedItem == null)
            {
                errors.AppendLine("Выберите код рейса.");
            }
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString(), "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            try
            {
                _schedule.DepartureTime = DateTime.ParseExact(dpDepartureTime.Text, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                _schedule.ArrivalTime = DateTime.ParseExact(dpArrivalTime.Text, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                _db.Schedules.Add(_schedule);
                _db.SaveChanges();
                MessageBox.Show("Запись добавлена.", "Успешно.", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка при сохранении изменений. Подробности: " + ex.Message);
            }
        }
    }
}
