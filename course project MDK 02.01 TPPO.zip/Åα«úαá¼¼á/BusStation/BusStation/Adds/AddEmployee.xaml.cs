﻿using BusStation.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BusStation.Adds
{
    /// <summary>
    /// Логика взаимодействия для AddEmployee.xaml
    /// </summary>
    public partial class AddEmployee : Window
    {
        BusStationContext _db = new BusStationContext();

        Employee _employee;

        public AddEmployee()
        {
            InitializeComponent();

            Height += 30;
            Width += 30;
        }
        /// <summary>
        /// Загрузка данных из кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Title = "Добавить запись.";
            btnAddEmployee.Content = "Добавить.";
            _employee = new Employee();
            DataContext = _employee;
        }
        /// <summary>
        /// Назад
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow("Guest");
            this.Close();
        }
        /// <summary>
        /// Добавление кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (txtContactInfo.Text.Length == 0 || txtName.Text.Length == 0 || txtPosition.Text.Length == 0)
            {
                MessageBox.Show("Заполните все поля!", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString(), "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            try
            {
                _employee.ContactInfo = txtContactInfo.Text;
                _employee.Name = txtName.Text;
                _employee.Position = txtPosition.Text;
                _db.Employees.Add(_employee);
                _db.SaveChanges();
                MessageBox.Show("Запись добавлена.", "Успешно.", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка при сохранении изменений. Подробности: " + ex.Message);
            }
        }
        /// <summary>
        /// Защита от некорректных значений
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtName_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            foreach (char c in e.Text)
            {
                if (!char.IsLetter(c))
                {
                    e.Handled = true;
                    MessageBox.Show("Проверьте правильность введенной информации.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
        }
        /// <summary>
        /// Защита от некорректных значений
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtPosition_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            foreach (char c in e.Text)
            {
                if (!char.IsLetter(c))
                {
                    e.Handled = true;
                    MessageBox.Show("Проверьте правильность введенной информации.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
        }
    }
}
