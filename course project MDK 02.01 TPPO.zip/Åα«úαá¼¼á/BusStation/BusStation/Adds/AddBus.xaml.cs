﻿using BusStation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BusStation.Adds
{
    /// <summary>
    /// Логика взаимодействия для AddBus.xaml
    /// </summary>
    public partial class AddBus : Window
    {
        BusStationContext _db = new BusStationContext();

        Bus _bus;

        public AddBus()
        {
            InitializeComponent();

            Height += 30;
            Width += 30;
        }
        /// <summary>
        /// Загрузка данных из таблицы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Title = "Добавить запись.";
            btnAddBus.Content = "Добавить.";
            _bus = new Bus();
            cbEmployeeId.ItemsSource = _db.Employees.ToList();
            cbEmployeeId.DisplayMemberPath = "EmployeeId";
            DataContext = _bus;
        }
        /// <summary>
        /// Назад
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow("Guest");
            this.Close();
        }
        /// <summary>
        /// Добавление кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddBus_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (txtCapacity.Text.Length == 0 || txtModel.Text.Length == 0 || txtPlateNumber.Text.Length == 0)
            {
                MessageBox.Show("Заполните все поля!", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (cbEmployeeId.SelectedItem == null)
            {
                errors.AppendLine("Выберите код сотрудника.");
            }
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString(), "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            try
            {
                _bus.Capacity = Convert.ToInt32(txtCapacity.Text);
                _bus.Model = txtModel.Text;
                _bus.PlateNumber = txtPlateNumber.Text;
                _db.Buses.Add(_bus);
                _db.SaveChanges();
                MessageBox.Show("Запись добавлена.", "Успешно.", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка при сохранении изменений. Подробности: " + ex.Message);
            }
        }
        /// <summary>
        /// Защита от некорректных значений
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtCapacity_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            foreach (char c in e.Text)
            {
                if (!char.IsDigit(c))
                {
                    e.Handled = true;
                    MessageBox.Show("Проверьте правильность введенной информации.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
        }
    }
}
