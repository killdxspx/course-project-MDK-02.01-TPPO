﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BusStation.Authorization
{
    /// <summary>
    /// Логика взаимодействия для AuthorizationWindow.xaml
    /// </summary>
    public partial class AuthorizationWindow : Window
    {
        public string UserRole { get; private set; } = "Guest";
        
        public AuthorizationWindow()
        {
            InitializeComponent();

            this.KeyDown += AuthorizationWindow_KeyDown;
        }
        /// <summary>
        /// Вход
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Password;
            if (username == "ad" && password == "123")
            {
                UserRole = "Admin";   
                OpenMainWindow();     
            }
            else if (username == "guest" && password == "guest")
            {
                UserRole = "Guest";   
                OpenMainWindow();     
            }
            else
            {
                MessageBox.Show("Неверные учетные данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                txtUsername.Clear();
                txtPassword.Clear();
            }
        }
        /// <summary>
        /// Выход из авторизации
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;  
            Close();  
        }
        /// <summary>
        /// Открытие главного окна при успешной авторизации
        /// </summary>
        private void OpenMainWindow()
        {
            MainWindow mainWindow = new MainWindow(UserRole);
            mainWindow.Show();
            this.Close();
        }
        /// <summary>
        /// Бинды для кнопок на клавиатуре
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AuthorizationWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                BtnLogin_Click(sender, e);
            }

            if (e.Key == Key.Escape)
            {
                Close();
            }
        }
    }
}