﻿using BusStation.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static BusStation.Data.ClassData;

namespace BusStation.Edits
{
    /// <summary>
    /// Логика взаимодействия для EditFlight.xaml
    /// </summary>
    public partial class EditFlight : Window
    {
        BusStationContext _db = new BusStationContext();

        Flight _flight;

        public EditFlight()
        {
            InitializeComponent();

            Height += 30;
            Width += 30;
        }
        /// <summary>
        /// Загрузка данных из кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Title = "Редактировать запись.";
            btnEditFlight.Content = "Редактировать.";
            _db.Flights.Load();
            _flight = _db.Flights.Find(DataFlight.flight.FlightId);
            dpDepartureTime.SelectedDate = DateTime.Parse(_flight.DepartureTime.ToString());
            dpArrivalTime.SelectedDate = DateTime.Parse(_flight.ArrivalTime.ToString());
            DataContext = _flight;
        }
        /// <summary>
        /// Назад
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow("Guest");
            this.Close();
        }
        /// <summary>
        /// Редактирование кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEditFlight_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (txtDestination.Text.Length == 0 || dpArrivalTime.Text.Length == 0 || dpDepartureTime.Text.Length == 0 || txtRouteNumber.Text.Length == 0)
            {
                MessageBox.Show("Заполните все поля!", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString(), "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            try
            {
                _flight.DepartureTime = System.DateTime.Parse(dpDepartureTime.Text);
                _flight.ArrivalTime = System.DateTime.Parse(dpArrivalTime.Text);
                _db.Flights.Update(_flight);
                _db.SaveChanges();
                MessageBox.Show("Запись изменена.", "Успешно.", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка при сохранении изменений. Подробности: " + ex.Message);
            }
        }
        /// <summary>
        /// Защита от некорректных значений
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtRouteNumber_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            foreach (char c in e.Text)
            {
                if (!char.IsDigit(c))
                {
                    e.Handled = true;
                    MessageBox.Show("Проверьте правильность введенной информации.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
        }
    }
}
