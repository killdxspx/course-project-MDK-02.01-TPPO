﻿using BusStation.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static BusStation.Data.ClassData;

namespace BusStation.Edits
{
    /// <summary>
    /// Логика взаимодействия для EditSchedule.xaml
    /// </summary>
    public partial class EditSchedule : Window
    {
        BusStationContext _db = new BusStationContext();

        Schedule _schedule;

        public EditSchedule()
        {
            InitializeComponent();

            Height += 30;
            Width += 30;
        }
        /// <summary>
        /// Загрузка данных из кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Title = "Редактировать запись.";
            btnEditSchedule.Content = "Редактировать.";
            _db.Schedules.Load();
            _schedule = _db.Schedules.Find(DataSchedule.schedule.ScheduleId);
            cbFlightId.ItemsSource = _db.Flights.ToList();
            cbFlightId.DisplayMemberPath = "FlightId";
            DataContext = _schedule;
        }
        /// <summary>
        /// Назад
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow("Guest");
            this.Close();
        }
        /// <summary>
        /// Редактирование кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEditSchedule_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (dpArrivalTime.Text.Length == 0 || dpDepartureTime.Text.Length == 0)
            {
                MessageBox.Show("Заполните все поля!", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            if (cbFlightId.SelectedItem == null)
            {
                errors.AppendLine("Выберите код рейса.");
            }
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString(), "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            try
            {
                _schedule.DepartureTime = DateTime.ParseExact(dpDepartureTime.Text, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                _schedule.ArrivalTime = DateTime.ParseExact(dpArrivalTime.Text, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                _db.Schedules.Update(_schedule);
                _db.SaveChanges();
                MessageBox.Show("Запись изменена.", "Успешно.", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Произошла ошибка при сохранении изменений. Подробности: " + ex.Message);
            }
        }
    }
}
