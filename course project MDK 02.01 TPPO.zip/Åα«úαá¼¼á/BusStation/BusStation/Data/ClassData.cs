﻿using BusStation.Mains;
using BusStation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusStation.Data
{
    internal class ClassData
    {
        public static class DataBus
        {
            public static Bus? bus;
        }

        public static class DataEmployee
        {
            public static Employee? employee;
        }

        public static class DataFlight
        {
            public static Flight? flight;
        }

        public static class DataSchedule
        {
            public static Schedule? schedule;
        }    
    }
}
