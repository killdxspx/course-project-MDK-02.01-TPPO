﻿using BusStation.Authorization;
using BusStation.Mains;
using System.Configuration;
using System.Data;
using System.Windows;

namespace BusStation
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            AuthorizationWindow authWindow = new AuthorizationWindow();
            bool? result = authWindow.ShowDialog();
        }
    }
}
