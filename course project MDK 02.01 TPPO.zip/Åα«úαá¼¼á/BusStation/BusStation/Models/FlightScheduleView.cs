﻿using System;
using System.Collections.Generic;

namespace BusStation.Models;

public partial class FlightScheduleView
{
    public int FlightId { get; set; }

    public string Destination { get; set; } = null!;

    public DateTime DepartureTime { get; set; }

    public DateTime ArrivalTime { get; set; }

    public string RouteNumber { get; set; } = null!;
}
