﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace BusStation.Models;

public partial class BusStationContext : DbContext
{
    public BusStationContext()
    {
    }

    public BusStationContext(DbContextOptions<BusStationContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Bus> Buses { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<EmployeePositionsView> EmployeePositionsViews { get; set; }

    public virtual DbSet<Flight> Flights { get; set; }

    public virtual DbSet<FlightScheduleView> FlightScheduleViews { get; set; }

    public virtual DbSet<FlightTicketsView> FlightTicketsViews { get; set; }

    public virtual DbSet<Schedule> Schedules { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        //=> optionsBuilder.UseSqlServer("Server=localhost; Database=BusStation; User=sa; Password=1234567890; Encrypt=false");
      => optionsBuilder.UseSqlServer("Server=localhost\\sqlexpress; Database=BusStation; User=исп-44; Password=1234567890; Encrypt=false");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Bus>(entity =>
        {
            entity.HasKey(e => e.BusId).HasName("PK__Bus__6A0F6095633F24DA");

            entity.ToTable("Bus");

            entity.Property(e => e.BusId).HasColumnName("BusID");
            entity.Property(e => e.EmployeeId).HasColumnName("EmployeeID");
            entity.Property(e => e.Model).HasMaxLength(50);
            entity.Property(e => e.PlateNumber).HasMaxLength(50);

            entity.HasOne(d => d.Employee).WithMany(p => p.Buses)
                .HasForeignKey(d => d.EmployeeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Bus__EmployeeID__412EB0B6");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.EmployeeId).HasName("PK__Employee__7AD04FF1F9F73720");

            entity.ToTable("Employee");

            entity.Property(e => e.EmployeeId).HasColumnName("EmployeeID");
            entity.Property(e => e.ContactInfo).HasMaxLength(50);
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.Position).HasMaxLength(50);
        });

        modelBuilder.Entity<EmployeePositionsView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("EmployeePositionsView");

            entity.Property(e => e.ContactInfo).HasMaxLength(50);
            entity.Property(e => e.EmployeeId)
                .ValueGeneratedOnAdd()
                .HasColumnName("EmployeeID");
            entity.Property(e => e.Name).HasMaxLength(50);
            entity.Property(e => e.Position).HasMaxLength(50);
        });

        modelBuilder.Entity<Flight>(entity =>
        {
            entity.HasKey(e => e.FlightId).HasName("PK__Flight__8A9E148E1707BA3D");

            entity.ToTable("Flight", tb =>
                {
                    tb.HasTrigger("DeleteTicketsOnFlightDelete");
                    tb.HasTrigger("UpdateScheduleOnFlightTimeChange");
                });

            entity.Property(e => e.FlightId).HasColumnName("FlightID");
            entity.Property(e => e.ArrivalTime).HasColumnType("datetime");
            entity.Property(e => e.DepartureTime).HasColumnType("datetime");
            entity.Property(e => e.Destination).HasMaxLength(50);
            entity.Property(e => e.RouteNumber).HasMaxLength(50);
        });

        modelBuilder.Entity<FlightScheduleView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("FlightScheduleView");

            entity.Property(e => e.ArrivalTime).HasColumnType("datetime");
            entity.Property(e => e.DepartureTime).HasColumnType("datetime");
            entity.Property(e => e.Destination).HasMaxLength(50);
            entity.Property(e => e.FlightId)
                .ValueGeneratedOnAdd()
                .HasColumnName("FlightID");
            entity.Property(e => e.RouteNumber).HasMaxLength(50);
        });

        modelBuilder.Entity<FlightTicketsView>(entity =>
        {
            entity
                .HasNoKey()
                .ToView("FlightTicketsView");

            entity.Property(e => e.FlightId).HasColumnName("FlightID");
            entity.Property(e => e.Price).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.Status).HasMaxLength(50);
            entity.Property(e => e.TicketId).HasColumnName("TicketID");
            entity.Property(e => e.TicketType).HasMaxLength(50);
        });

        modelBuilder.Entity<Schedule>(entity =>
        {
            entity.HasKey(e => e.ScheduleId).HasName("PK__Schedule__9C8A5B69A58B975E");

            entity.ToTable("Schedule");

            entity.Property(e => e.ScheduleId).HasColumnName("ScheduleID");
            entity.Property(e => e.ArrivalTime).HasColumnType("datetime");
            entity.Property(e => e.DepartureTime).HasColumnType("datetime");
            entity.Property(e => e.FlightId).HasColumnName("FlightID");

            entity.HasOne(d => d.Flight).WithMany(p => p.Schedules)
                .HasForeignKey(d => d.FlightId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Schedule__Flight__3C69FB99");
        });
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
