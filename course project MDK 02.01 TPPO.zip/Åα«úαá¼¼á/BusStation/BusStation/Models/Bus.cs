﻿using System;
using System.Collections.Generic;

namespace BusStation.Models;

public partial class Bus
{
    public int BusId { get; set; }

    public int EmployeeId { get; set; }

    public string Model { get; set; } = null!;

    public string PlateNumber { get; set; } = null!;

    public int Capacity { get; set; }

    public virtual Employee Employee { get; set; } = null!;
}
