﻿using System;
using System.Collections.Generic;

namespace BusStation.Models;

public partial class Schedule
{
    public int ScheduleId { get; set; }

    public int FlightId { get; set; }

    public DateTime DepartureTime { get; set; }

    public DateTime ArrivalTime { get; set; }

    public virtual Flight Flight { get; set; } = null!;
}
