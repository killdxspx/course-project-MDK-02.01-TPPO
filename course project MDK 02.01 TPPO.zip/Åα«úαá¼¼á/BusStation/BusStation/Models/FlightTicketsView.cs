﻿using System;
using System.Collections.Generic;

namespace BusStation.Models;

public partial class FlightTicketsView
{
    public int TicketId { get; set; }

    public int FlightId { get; set; }

    public string TicketType { get; set; } = null!;

    public decimal Price { get; set; }

    public string Status { get; set; } = null!;
}
