﻿using BusStation.Adds;
using BusStation.Edits;
using BusStation.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static BusStation.Data.ClassData;

namespace BusStation.Mains
{
    /// <summary>
    /// Логика взаимодействия для EmployeeWindow.xaml
    /// </summary>
    public partial class EmployeeWindow : Window
    {
        private string UserRole;

        public EmployeeWindow(string userRole)
        {
            InitializeComponent();

            Height += 30;
            Width += 30;

            UserRole = userRole;
            SetAccessRights();
        }
        /// <summary>
        /// Загрузка таблицы
        /// </summary>
        void LoadDBInDataGrid()
        {
            using (BusStationContext _db = new BusStationContext())
            {
                int selectedIndex = dgEmployee.SelectedIndex;
                _db.Employees.Load();
                dgEmployee.ItemsSource = _db.Employees.ToList();
                if (selectedIndex != -1)
                {
                    if (selectedIndex == dgEmployee.Items.Count)
                    {
                        selectedIndex--;
                    }
                    dgEmployee.SelectedIndex = selectedIndex;
                    dgEmployee.ScrollIntoView(dgEmployee.SelectedItem);
                }
                dgEmployee.Focus();
            }
        }
        /// <summary>
        /// Автоматическое обновление таблицы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Назад
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow("Guest");
            this.Close();
        }
        /// <summary>
        /// Ручное обнавление таблицы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnLoad_Click(object sender, RoutedEventArgs e)
        {
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Переход на окно добавления
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddEmployee_Click(object sender, RoutedEventArgs e)
        {
            AddEmployee addEmployee = new AddEmployee();
            addEmployee.ShowDialog();
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Переход на окно редактирования
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEditEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (dgEmployee.SelectedItem != null)
            {
                DataEmployee.employee = (Employee)dgEmployee.SelectedItem;
                EditEmployee editEmployee = new EditEmployee();
                editEmployee.ShowDialog();
                LoadDBInDataGrid();
            }           
        }
        /// <summary>
        /// Удаление кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeletEmployee_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result;
            result = MessageBox.Show("Удалить запись?", "Удаление записи.", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    Employee row = (Employee)dgEmployee.SelectedItem;
                    if (row != null)
                    {
                        using (BusStationContext _db = new BusStationContext())
                        {
                            _db.Employees.Remove(row);
                            _db.SaveChanges();
                        }
                        LoadDBInDataGrid();
                    }
                }
                catch
                {
                    MessageBox.Show("Ошибка.", "Ошибка удаления.", MessageBoxButton.OKCancel, MessageBoxImage.Error);
                }
            }
            else
            {
                dgEmployee.Focus();
            }
        }
        /// <summary>
        /// Поиск
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearchEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearchEmployee.Text))
            {
                MessageBox.Show("Пожалуйста, введите значение для поиска.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                List<Employee> listItem = (List<Employee>)dgEmployee.ItemsSource;
                var filtered = listItem.Where(p => p.EmployeeId.ToString().Contains(txtSearchEmployee.Text));
                if (filtered.Count() > 0)
                {
                    var item = filtered.First();
                    dgEmployee.SelectedItem = item;
                    dgEmployee.ScrollIntoView(item);
                    dgEmployee.Focus();
                }
                else
                {
                    MessageBox.Show("Ничего не найдено.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        /// <summary>
        /// Защита от некорректных значений
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtSearchEmployee_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            foreach (char c in e.Text)
            {
                if (!char.IsDigit(c))
                {
                    e.Handled = true;
                    MessageBox.Show("Проверьте правильность введенной информации.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
        }
        /// <summary>
        /// Параметры для гостя
        /// </summary>
        private void SetAccessRights()
        {
            if (UserRole == "Guest")
            {
                btnAddEmployee.IsEnabled = false;
                btnEditEmployee.IsEnabled = false;
                btnDeletEmployee.IsEnabled = false;
            }
        }
    }
}
