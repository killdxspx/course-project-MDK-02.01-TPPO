﻿using BusStation.Adds;
using BusStation.Edits;
using BusStation.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static BusStation.Data.ClassData;

namespace BusStation.Mains
{
    /// <summary>
    /// Логика взаимодействия для FlightWindow.xaml
    /// </summary>
    public partial class FlightWindow : Window
    {
        private string UserRole;

        public FlightWindow(string userRole)
        {
            InitializeComponent();

            Height += 30;
            Width += 30;

            UserRole = userRole;
            SetAccessRights();
        }
        /// <summary>
        /// Загрузка таблицы
        /// </summary>
        void LoadDBInDataGrid()
        {
            using (BusStationContext _db = new BusStationContext())
            {
                int selectedIndex = dgFlight.SelectedIndex;
                _db.Flights.Load();
                dgFlight.ItemsSource = _db.Flights.ToList();
                if (selectedIndex != -1)
                {
                    if (selectedIndex == dgFlight.Items.Count)
                    {
                        selectedIndex--;
                    }
                    dgFlight.SelectedIndex = selectedIndex;
                    dgFlight.ScrollIntoView(dgFlight.SelectedItem);
                }
                dgFlight.Focus();
            }
        }
        /// <summary>
        /// Автоматическое обновление таблицы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Назад
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow("Guest");
            this.Close();
        }
        /// <summary>
        /// Ручное обнавление таблицы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnLoad_Click(object sender, RoutedEventArgs e)
        {
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Переход на окно добавления
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddFlight_Click(object sender, RoutedEventArgs e)
        {
            AddFlight addFlight = new AddFlight();
            addFlight.ShowDialog();
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Переход на окно редактирования
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEditFlight_Click(object sender, RoutedEventArgs e)
        {
            if (dgFlight.SelectedItem != null)
            {
                DataFlight.flight = (Flight)dgFlight.SelectedItem;
                EditFlight editFlight = new EditFlight();
                editFlight.ShowDialog();
                LoadDBInDataGrid();
            }
        }
        /// <summary>
        /// Удаление кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeletFlight_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result;
            result = MessageBox.Show("Удалить запись?", "Удаление записи.", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    Flight row = (Flight)dgFlight.SelectedItem;
                    if (row != null)
                    {
                        using (BusStationContext _db = new BusStationContext())
                        {
                            _db.Flights.Remove(row);
                            _db.SaveChanges();
                        }
                        LoadDBInDataGrid();
                    }
                }
                catch
                {
                    MessageBox.Show("Ошибка.", "Ошибка удаления.", MessageBoxButton.OKCancel, MessageBoxImage.Error);
                }
            }
            else
            {
                dgFlight.Focus();
            }
        }
        /// <summary>
        /// Поиск
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearchFlight_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearchFlight.Text))
            {
                MessageBox.Show("Пожалуйста, введите значение для поиска.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                List<Flight> listItem = (List<Flight>)dgFlight.ItemsSource;
                var filtered = listItem.Where(p => p.FlightId.ToString().Contains(txtSearchFlight.Text));
                if (filtered.Count() > 0)
                {
                    var item = filtered.First();
                    dgFlight.SelectedItem = item;
                    dgFlight.ScrollIntoView(item);
                    dgFlight.Focus();
                }
                else
                {
                    MessageBox.Show("Ничего не найдено.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        /// <summary>
        /// Защита от некорректных значений
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtSearchFlight_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            foreach (char c in e.Text)
            {
                if (!char.IsDigit(c))
                {
                    e.Handled = true;
                    MessageBox.Show("Проверьте правильность введенной информации.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
        }
        /// <summary>
        /// Параметры гостя
        /// </summary>
        private void SetAccessRights()
        {
            if (UserRole == "Guest")
            {
                btnAddFlight.IsEnabled = false;
                btnEditFlight.IsEnabled = false;
                btnDeletFlight.IsEnabled = false;
            }
        }
    }
}
