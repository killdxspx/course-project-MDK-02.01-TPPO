﻿using BusStation.Adds;
using BusStation.Edits;
using BusStation.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static BusStation.Data.ClassData;

namespace BusStation.Mains
{
    /// <summary>
    /// Логика взаимодействия для BusWindow.xaml
    /// </summary>
    public partial class BusWindow : Window
    {
        private string UserRole;

        public BusWindow(string userRole)
        {
            InitializeComponent();

            Height += 30;
            Width += 30;

            UserRole = userRole;
            SetAccessRights();
        }

        /// <summary>
        /// Загрузка таблицы
        /// </summary>
        void LoadDBInDataGrid()
        {
            using (BusStationContext _db = new BusStationContext())
            {
                int selectedIndex = dgBus.SelectedIndex;
                _db.Buses.Load();
                _db.Employees.Load();
                dgBus.ItemsSource = _db.Buses.ToList();
                if (selectedIndex != -1)
                {
                    if (selectedIndex == dgBus.Items.Count)
                    {
                        selectedIndex--;
                    }
                    dgBus.SelectedIndex = selectedIndex;
                    dgBus.ScrollIntoView(dgBus.SelectedItem);
                }
                dgBus.Focus();
            }
        }
        /// <summary>
        /// Автоматическое обновление таблицы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Назад
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow("Guest");
            this.Close();
        }
        /// <summary>
        /// Ручное обнавление таблицы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnLoad_Click(object sender, RoutedEventArgs e)
        {
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Переход на окно добавления
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddBus_Click(object sender, RoutedEventArgs e)
        {
            AddBus addBus = new AddBus();
            addBus.ShowDialog();
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Переход на окно редактирования
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEditBus_Click(object sender, RoutedEventArgs e)
        {
            if (dgBus.SelectedItem != null)
            {
                DataBus.bus = (Bus)dgBus.SelectedItem;
                EditBus editBus = new EditBus();
                editBus.ShowDialog();
                LoadDBInDataGrid();
            }
        }
        /// <summary>
        /// Удаление кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeletBus_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result;
            result = MessageBox.Show("Удалить запись?", "Удаление записи.", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    Bus row = (Bus)dgBus.SelectedItem;
                    if (row != null)
                    {
                        using (BusStationContext _db = new BusStationContext())
                        {
                            _db.Buses.Remove(row);
                            _db.SaveChanges();
                        }
                        LoadDBInDataGrid();
                    }
                }
                catch
                {
                    MessageBox.Show("Ошибка.", "Ошибка удаления.", MessageBoxButton.OKCancel, MessageBoxImage.Error);
                }
            }
            else
            {
                dgBus.Focus();
            }
        }
        /// <summary>
        /// Поиск
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearchBus_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearchBus.Text))
            {
                MessageBox.Show("Пожалуйста, введите значение для поиска.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                List<Bus> listItem = (List<Bus>)dgBus.ItemsSource;
                var filtered = listItem.Where(p => p.BusId.ToString().Contains(txtSearchBus.Text));
                if (filtered.Count() > 0)
                {
                    var item = filtered.First();
                    dgBus.SelectedItem = item;
                    dgBus.ScrollIntoView(item);
                    dgBus.Focus();
                }
                else
                {
                    MessageBox.Show("Ничего не найдено.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        /// <summary>
        /// Защита от некорректных значений
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtSearchBus_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            foreach (char c in e.Text)
            {
                if (!char.IsDigit(c))
                {
                    e.Handled = true;
                    MessageBox.Show("Проверьте правильность введенной информации.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
        }
        /// <summary>
        /// Параметры для гостя
        /// </summary>
        private void SetAccessRights()
        {
            if (UserRole == "Guest")
            {
                btnAddBus.IsEnabled = false;
                btnEditBus.IsEnabled = false;
                btnDeletBus.IsEnabled = false;
            }
        }
    }
}
