﻿using BusStation.Adds;
using BusStation.Edits;
using BusStation.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static BusStation.Data.ClassData;

namespace BusStation.Mains
{
    /// <summary>
    /// Логика взаимодействия для ScheduleWindow.xaml
    /// </summary>
    public partial class ScheduleWindow : Window
    {
        private string UserRole;

        public ScheduleWindow(string userRole)
        {
            InitializeComponent();

            Height += 30;
            Width += 30;

            UserRole = userRole;
            SetAccessRights();
        }
        /// <summary>
        /// Загрузка таблицы
        /// </summary>
        void LoadDBInDataGrid()
        {
            using (BusStationContext _db = new BusStationContext())
            {
                int selectedIndex = dgSchedule.SelectedIndex;
                _db.Schedules.Load();
                dgSchedule.ItemsSource = _db.Schedules.ToList();
                if (selectedIndex != -1)
                {
                    if (selectedIndex == dgSchedule.Items.Count)
                    {
                        selectedIndex--;
                    }
                    dgSchedule.SelectedIndex = selectedIndex;
                    dgSchedule.ScrollIntoView(dgSchedule.SelectedItem);
                }
                dgSchedule.Focus();
            }
        }
        /// <summary>
        /// Автоматическое обновление таблицы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Назад
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow("Guest");
            this.Close();
        }
        /// <summary>
        /// Ручное обнавление таблицы
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void mnLoad_Click(object sender, RoutedEventArgs e)
        {
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Переход на окно добавления
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAddSchedule_Click(object sender, RoutedEventArgs e)
        {
            AddSchedule addSchedule = new AddSchedule();
            addSchedule.ShowDialog();
            LoadDBInDataGrid();
        }
        /// <summary>
        /// Переход на окно редактирования
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEditSchedule_Click(object sender, RoutedEventArgs e)
        {
            if (dgSchedule.SelectedItem != null)
            {
                DataSchedule.schedule = (Schedule)dgSchedule.SelectedItem;
                EditSchedule editSchedule = new EditSchedule();
                editSchedule.ShowDialog();
                LoadDBInDataGrid();
            }
        }
        /// <summary>
        /// Удаление кортежа
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDeletSchedule_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result;
            result = MessageBox.Show("Удалить запись?", "Удаление записи.", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    Schedule row = (Schedule)dgSchedule.SelectedItem;
                    if (row != null)
                    {
                        using (BusStationContext _db = new BusStationContext())
                        {
                            _db.Schedules.Remove(row);
                            _db.SaveChanges();
                        }
                        LoadDBInDataGrid();
                    }
                }
                catch
                {
                    MessageBox.Show("Ошибка.", "Ошибка удаления.", MessageBoxButton.OKCancel, MessageBoxImage.Error);
                }
            }
            else
            {
                dgSchedule.Focus();
            }
        }
        /// <summary>
        /// Поиск
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSearchSchedule_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearchSchedule.Text))
            {
                MessageBox.Show("Пожалуйста, введите значение для поиска.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                List<Schedule> listItem = (List<Schedule>)dgSchedule.ItemsSource;
                var filtered = listItem.Where(p => p.ScheduleId.ToString().Contains(txtSearchSchedule.Text));
                if (filtered.Count() > 0)
                {
                    var item = filtered.First();
                    dgSchedule.SelectedItem = item;
                    dgSchedule.ScrollIntoView(item);
                    dgSchedule.Focus();
                }
                else
                {
                    MessageBox.Show("Ничего не найдено.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        /// <summary>
        /// Защита от некорректных значений
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtSearchSchedule_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            foreach (char c in e.Text)
            {
                if (!char.IsDigit(c))
                {
                    e.Handled = true;
                    MessageBox.Show("Проверьте правильность введенной информации.", "Ошибка.", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
            }
        }
        /// <summary>
        /// Параметры для гостя
        /// </summary>
        private void SetAccessRights()
        {
            if (UserRole == "Guest")
            {
                btnAddSchedule.IsEnabled = false;
                btnEditSchedule.IsEnabled = false;
                btnDeletSchedule.IsEnabled = false;
            }
        }
    }
}
